#include <stdio.h>
void main ()
{
    int l , b ;
    int area;
    printf("Enter the length =");
    scanf("%d" , &l);
    printf("Enter the Breadth =");
    scanf("%d" , &b);
    area = l*b;
    printf("Area = %d" , area);
    
}