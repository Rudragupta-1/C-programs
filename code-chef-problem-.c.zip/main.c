#include <stdio.h>

int main(void) {
	int n,a,b,c,d;
	scanf("%d",&n);
	while(n--)
	{
	    scanf("%d %d",&a,&b);
	    c=a*2;
	    d=b*5;
	    if(c>d)
	    printf("Chocolate\n");
	    else if(c<d)
	    printf("Candy\n");
	    else
	    printf("Either\n");
	    
	}
	return 0;
}

