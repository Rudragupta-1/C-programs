#include <stdio.h>
int main()
{
    int a = 10;
    int b = 20;
    int  temp;
    printf("a=%d\n" , a);
    printf("b=%d\n" , b);
    temp=a;
    a=b;
    b=temp;
    printf("a=%d" , a);
    
    printf("b=%d" , b);
    return 0;
    
}