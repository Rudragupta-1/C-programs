#include <stdio.h>
int main()
{
    int a , b ;
    printf("Enter the value of A : ");
    scanf("%d" , &a);
    printf("Enter the value of B : ");
    scanf("%d" , &b);
    
    int temp ;
    temp = a ;
    a = b ;
    temp = b ;
    printf("Enter the value of A :");
    scanf("%d", &a);
    printf("Enter the value of B :");
    scanf("%d", &b);
    return 0;
    
}